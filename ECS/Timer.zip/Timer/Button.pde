class Button {
  // Member Variables
  int x, y, w, h;
  String label;
  
  // Constructor
  Button(int x, int y, int w, int h, String label) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.label = label;
  }
  
  void display() {
   rectMode(CENTER);
  
  if (isMouseOver()) {
    stroke(0, 200, 255, 150); 
    strokeWeight(4);
    fill(60, 80, 120);
    noStroke();
    fill(0, 40);
    rect(x + 4, y + 4, w, h); 
  } else {
    stroke(100);
    strokeWeight(1);
    fill(30, 35, 50);
  }

  // Main Button Body
  rect(x, y, w, h, 5);
  
  // Text Styling
  fill(255);
  if (isMouseOver()) fill(0, 255, 255);
  textAlign(CENTER, CENTER);
  textSize(20);
  text(label, x, y - 2);
}
  
  boolean isMouseOver() {
    return mouseX > x-w/2 && mouseX < x+w/2 && mouseY > y-h/2 && mouseY < y+h/2;
  }
  
  boolean wasClicked() {
    return true;
  }
}
